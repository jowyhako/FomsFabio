﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EX03
{
    public partial class frmPrincipal : Form
    {

        int cupomFiscal = 0;
        double valorTotalProdutos = 0, SomatorioProdutos = 0;
        int totalItensComprados = 0;
        String itemSelecionado;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void chkNotaPaulista_CheckedChanged(object sender, EventArgs e)
        {
            if (chkNotaPaulista.Checked == true)
            {
                mskCPF.Enabled = true;
                mskCPF.Focus();
            }
            else
                {
                mskCPF.Enabled = false;
            }
           
        }

        private void btnAbreCupom_Click(object sender, EventArgs e)
        {
        
            if (mskCPF == null)
            {
                MessageBox.Show("Preencha o CPF");
            }
            else 
            {
                MessageBox.Show("CPF Cadastrado!");
                chkNotaPaulista.Enabled = false;
                mskCPF.Enabled = false;
                grpProdutoAtual.Enabled = true;
                txtCodigoBarras.Focus();
                lblCupomFiscal.Visible = true;
                cupomFiscal += 1;
                lblCupomFiscal.Text = "Cupom Nº: " + cupomFiscal;
                btnAbreCupom.Enabled = false;
            }

            
        }
       
        

        private void btnFinalizaCompra_Click(object sender, EventArgs e)
        {
            grpFormaPagamento.Enabled = true;
            btnPagamento.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SalvarCupomFiscal();
            double troco=0;
            bool compraFinalizada = false;
            if (rdbCredito.Checked == true)
            {
                MessageBox.Show("Pagamento efetuado com cartão de crédito! Compra finalizada com sucesso.", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                compraFinalizada = true;
                mskCPF.Enabled = true;
                mskCPF.Clear();
            }
            else if (rdbDebito.Checked == true)
            {
                MessageBox.Show("Pagamento efetuado com cartão de débito! Compra finalizada com sucesso.", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                compraFinalizada = true;
                mskCPF.Enabled = true;
                mskCPF.Clear();
            }
            else if (rdbDinheiro.Checked == true)
            {
                if (Double.Parse(txtValorRecebido.Text) < SomatorioProdutos)
                {
                    MessageBox.Show("Pagamento NÃO efetuado. Valor menor que o valor da compra.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtValorRecebido.Text = "";
                    txtValorRecebido.Focus();
                    compraFinalizada = false;
                    mskCPF.Enabled = true;
                    mskCPF.Clear();
                }
                else
                {
                    troco = Double.Parse(txtValorRecebido.Text) - SomatorioProdutos;
                    lblTroco.Text += " " + troco;
                    lblTroco.Visible = true;
                    MessageBox.Show("Pagamento efetuado com dinheiro. Verifique o troco! Compra finalizada com sucesso.", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    compraFinalizada = true;
                    mskCPF.Enabled = true;
                    mskCPF.Clear();
                }

               }

            //Limpar campos
            if (compraFinalizada == true)
            {
                chkNotaPaulista.Enabled = true;
                btnAbreCupom.Enabled = true;
                lblCupomFiscal.Visible = false;
                lstItensCupom.Items.Clear();
                lblTotalCompra.Visible = false;
                troco = 0;
                lblTroco.Text = "Troco: R$";
                lblQuantidadeItens.Visible = false;
                totalItensComprados = 0;
                SomatorioProdutos = 0;
                lblTotalCompra.Text = "";
                valorTotalProdutos = 0;
                lblTroco.Visible = false;
                txtValorRecebido.Text = "";
                txtValorRecebido.Enabled = false;
                grpProdutoAtual.Enabled = false;
                btnPagamento.Enabled = false;
                rdbDebito.Checked = true;
                grpFormaPagamento.Enabled = false;
                mskCPF.Enabled = true;
                mskCPF.Clear();

            }


        }

        private void rdbDinheiro_CheckedChanged(object sender, EventArgs e)
        {
            lblValorRecebido.Enabled = true;
            txtValorRecebido.Enabled = true;
            txtValorRecebido.Focus();
            mskCPF.Enabled = true;
            mskCPF.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            itemSelecionado = lstItensCupom.SelectedItem.ToString();

            txtSenha.Enabled = true;
            btnConfirmaSenha.Enabled = true;

            txtSenha.Focus();
            

        }

        private void lstItensCupom_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRemoverProduto.Enabled = true;
        }

        private void btnConfirmaSenha_Click(object sender, EventArgs e)
        {
            int senhaPadrao = 1234;
            int senhaDigitada=0;

            //Substring Variáveis
            string[] partes;
            string preco, quantidade;
            double totalRemover=0;

            string itemSelecionadoRemover;
            senhaDigitada = int.Parse(txtSenha.Text);
            if (senhaDigitada != senhaPadrao)
            {
                MessageBox.Show("Senha Inválida. Produto não excluído", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Text = "";
                txtSenha.Enabled = false;
                btnConfirmaSenha.Enabled = false;
                lstItensCupom.SelectedIndex = -1;
                txtCodigoBarras.Focus();
                btnRemoverProduto.Enabled = false;
            }
            else
            {
                lstItensCupom.Items.Remove(itemSelecionado);
                itemSelecionadoRemover = itemSelecionado;

                //Substring
                partes = itemSelecionadoRemover.Substring(1).Split('|');
                preco = partes[3];
                quantidade = partes[2];
                totalRemover = double.Parse(partes[3]) * double.Parse(partes[2]);
                SomatorioProdutos = SomatorioProdutos - totalRemover;
                lblTotalCompra.Text = "R$ " + SomatorioProdutos.ToString("n2");
                totalItensComprados = totalItensComprados - 1;
                lblQuantidadeItens.Text = "Itens: " + totalItensComprados.ToString();

                if (totalItensComprados == 0)
                    btnPagamento.Enabled = false;
                else
                    btnPagamento.Enabled = true;

                MessageBox.Show("Item removido com sucesso", "Removido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSenha.Text = "";
                txtSenha.Enabled = false;
                btnConfirmaSenha.Enabled = false;
                lstItensCupom.SelectedIndex = -1;
                txtCodigoBarras.Focus();
                btnRemoverProduto.Enabled = false;
            }

        }

        private void btnCancelarCupom_Click(object sender, EventArgs e)
        {
            cupomFiscal = cupomFiscal - 1;
            lblCupomFiscal.Text = "Cupom Nº: " + cupomFiscal;
            //Limpar Tudo.

        }

        private void rdbDebito_CheckedChanged(object sender, EventArgs e)
        {
            txtValorRecebido.Enabled = false;
            lblValorRecebido.Enabled = false;
        }

        private void rdbCredito_CheckedChanged(object sender, EventArgs e)
        {
            txtValorRecebido.Enabled = false;
            lblValorRecebido.Enabled = false;


        }

        private void mskCPF_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void grpDadosClientes_Enter(object sender, EventArgs e)
        {

        }

        private void txtCodigoBarras_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCodigoBarras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar))
                e.Handled = true;
        }

        private void txtDescricao_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtDescricao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void txtPrecoUnitario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsLetter(e.KeyChar))
                e.Handled = true;
        }

        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtQuantidade_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (Char.IsLetter(e.KeyChar))
                e.Handled = true;
        }

        private void mskCPF_MaskChanged(object sender, EventArgs e)
        {
            if (mskCPF != null)
            {
                MessageBox.Show("Preencha o CPF");

            }
            else
            {
                chkNotaPaulista.Enabled = false;
                mskCPF.Enabled = false;
                grpProdutoAtual.Enabled = true;
                txtCodigoBarras.Focus();
                lblCupomFiscal.Visible = true;
                cupomFiscal += 1;
                lblCupomFiscal.Text = "Cupom Nº: " + cupomFiscal;
                btnAbreCupom.Enabled = false;
            }
        }

        private void lblQuantidadeItens_Click(object sender, EventArgs e)
        {

        }

        private void lblTotalCompra_Click(object sender, EventArgs e)
        {

        }
        private void SalvarCupomFiscal()
        {
            //System.NotSupportedException: 'Não há suporte para o formato do caminho dado.' tava dando isso e tive q pesquisar oq dá pra fazer, aparentemente nao aceita caracteres diferentes
            string numeroCupom = lblCupomFiscal.Text;

           
            string nomeArquivo = $"CF{numeroCupom}.txt";

            
            foreach (char c in System.IO.Path.GetInvalidFileNameChars())
            {
                nomeArquivo = nomeArquivo.Replace(c, '_'); 
            }

            
            StringBuilder conteudoCupom = new StringBuilder();
            conteudoCupom.AppendLine($"Cupom Fiscal Nº: {numeroCupom}");
            conteudoCupom.AppendLine("Itens Comprados:");

            
            foreach (var item in lstItensCupom.Items)
            {
                conteudoCupom.AppendLine(item.ToString());
            }

          
            conteudoCupom.AppendLine($"Total de Itens: {lstItensCupom.Items.Count}");
            conteudoCupom.AppendLine($"Valor Total: R$ {lblTotalCompra.Text}");

         
            string pathCompleto = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), nomeArquivo);
            System.IO.File.WriteAllText(pathCompleto, conteudoCupom.ToString());

            
            MessageBox.Show($"Cupom fiscal salvo no arquivo: {pathCompleto}", "Cupom Fiscal Salvo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnFinalizaCompra_Click_1(object sender, EventArgs e)
        {
            
            if (txtCodigoBarras.Text != string.Empty)
            {
              
                string nomeArquivo = $"{txtCodigoBarras.Text}.txt";
                string pathCompleto = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), nomeArquivo);

               
                if (System.IO.File.Exists(pathCompleto))
                {
                  
                    string conteudoProduto = System.IO.File.ReadAllText(pathCompleto);

                   
                    MessageBox.Show(conteudoProduto, "Produto Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                  
                    MessageBox.Show("Produto não encontrado.", "Erro de Consulta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o código de barras para consulta.", "Erro de Consulta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void lblCodigoBarras_Click(object sender, EventArgs e)
        {

        }

        private void txtPrecoUnitario_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastrarProduto_Click(object sender, EventArgs e)
        {
            if (txtCodigoBarras.Text != string.Empty && txtDescricao.Text != string.Empty && txtPrecoUnitario.Text != string.Empty)
            {
               
                StringBuilder produtoCadastro = new StringBuilder();
                produtoCadastro.AppendLine($"Código de Barras: {txtCodigoBarras.Text}");
                produtoCadastro.AppendLine($"Descrição: {txtDescricao.Text}");
                produtoCadastro.AppendLine($"Preço Unitário: {txtPrecoUnitario.Text}");

               
                string nomeArquivo = $"{txtCodigoBarras.Text}.txt";

               
                string pathCompleto = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), nomeArquivo);

               //mt interrante isso
                System.IO.File.WriteAllText(pathCompleto, produtoCadastro.ToString());
               
                MessageBox.Show($"Produto cadastrado com sucesso! Arquivo salvo em: {pathCompleto}", "Cadastro de Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpar
                txtCodigoBarras.Clear();
                txtDescricao.Clear();
                txtPrecoUnitario.Clear();
                txtCodigoBarras.Focus();
            }
            else
            {
                MessageBox.Show("Por favor, preencha todos os campos!", "Erro de Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnAdicionarProduto_Click(object sender, EventArgs e)
        {
            if (txtCodigoBarras.Text != string.Empty && txtDescricao.Text != string.Empty && txtPrecoUnitario.Text != string.Empty && txtQuantidade.Text != string.Empty)
            {


                string itemMenu = "";
                btnPagamento.Enabled = true;
                itemMenu = txtCodigoBarras.Text + " | " + txtDescricao.Text + " | " + txtQuantidade.Text + " | " + txtPrecoUnitario.Text + " | ";
                lstItensCupom.Items.Add(itemMenu);
                valorTotalProdutos = Double.Parse(txtPrecoUnitario.Text) * Double.Parse(txtQuantidade.Text);
                SomatorioProdutos = SomatorioProdutos + valorTotalProdutos;
                totalItensComprados += 1;



                txtCodigoBarras.Text = "";
                txtDescricao.Text = "";
                txtQuantidade.Text = "";
                txtPrecoUnitario.Text = "";
                txtCodigoBarras.Focus();

                lblTotalCompra.Visible = true;
                lblQuantidadeItens.Visible = true;
                lblTotalCompra.Text = "R$ " + SomatorioProdutos.ToString("n2");
                lblQuantidadeItens.Text = "Itens: " + totalItensComprados.ToString();
            }
            else {
                MessageBox.Show("Preencha todos os campos corretamente.");
            }
        }
    }
}
